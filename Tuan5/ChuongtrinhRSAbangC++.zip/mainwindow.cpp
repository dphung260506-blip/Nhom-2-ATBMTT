#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QGroupBox>
#include <QMessageBox>
#include <QApplication>
#include <QClipboard>
#include <QTabWidget>
#include <utility>
#include <tuple>
#include <random>
#include <chrono>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
    this->setWindowTitle("RSA Crypto - Công Cụ Mã Hóa Hiện Đại");
    this->resize(950, 680);

    // Áp dụng bộ Stylesheet giao diện phẳng (Flat Design) cao cấp
    this->setStyleSheet(
        "QMainWindow { background-color: #F8F9FA; }"
        "QLabel { color: #2B2D42; font-family: 'Segoe UI'; font-size: 13px; font-weight: 500; }"
        "QLineEdit, QTextEdit {"
        "   background-color: #FFFFFF; border: 1px solid #D8DEE9;"
        "   border-radius: 6px; padding: 8px; color: #2B2D42;"
        "   font-family: 'Consolas', 'Monaco', monospace; font-size: 13px;"
        "}"
        "QLineEdit:focus, QTextEdit:focus {"
        "   border: 2px solid #4361EE;"
        "}"
        "QGroupBox {"
        "   font-family: 'Segoe UI'; font-weight: bold; font-size: 14px; color: #4361EE;"
        "   border: 1px solid #E5E5E5; border-radius: 10px; margin-top: 15px; background-color: #FFFFFF;"
        "}"
        "QGroupBox::title { subcontrol-origin: margin; left: 15px; padding: 0 5px; }"
        "QTabWidget::pane { border: 1px solid #E5E5E5; border-radius: 8px; background-color: #FFFFFF; top: -1px; }"
        "QTabBar::tab {"
        "   background: #E9ECEF; color: #495057; padding: 10px 20px; font-weight: bold;"
        "   border-top-left-radius: 6px; border-top-right-radius: 6px; min-width: 120px;"
        "}"
        "QTabBar::tab:selected {"
        "   background: #FFFFFF; color: #4361EE; border-bottom: 3px solid #4361EE;"
        "}"
        );

    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);
    mainLayout->setContentsMargins(20, 20, 20, 20);
    mainLayout->setSpacing(15);

    // Tiêu đề ứng dụng lớn
    QLabel *lblTitle = new QLabel("RSA ENCRYPTION & DECRYPTION SYSTEM", this);
    lblTitle->setStyleSheet("font-size: 18px; font-weight: 800; color: #3F37C9; letter-spacing: 1px;");
    mainLayout->addWidget(lblTitle, 0, Qt::AlignCenter);

    // ==========================================
    // 1. CỤM CẤU HÌNH KHÓA
    // ==========================================
    QGroupBox *boxKey = new QGroupBox(" CẤU HÌNH KHÓA ", this);
    QGridLayout *keyLayout = new QGridLayout(boxKey);
    keyLayout->setContentsMargins(15, 20, 15, 15);
    keyLayout->setSpacing(10);

    txtP = new QLineEdit(); txtQ = new QLineEdit(); txtN = new QLineEdit(); txtE = new QLineEdit(); txtD = new QLineEdit();
    txtN->setReadOnly(true); txtE->setReadOnly(true); txtD->setReadOnly(true);

    txtP->setPlaceholderText("Ví dụ: 61");
    txtQ->setPlaceholderText("Ví dụ: 53");

    btnGenerate = new QPushButton("Sinh Tự Động");
    btnCalculate = new QPushButton("Tính Khóa Khả Dụng");

    btnGenerate->setStyleSheet("QPushButton { background-color: #7209B7; color: white; font-weight: bold; border-radius: 6px; padding: 8px 15px; border: none; }"
                               "QPushButton:hover { background-color: #560BAD; }");
    btnCalculate->setStyleSheet("QPushButton { background-color: #4361EE; color: white; font-weight: bold; border-radius: 6px; padding: 8px 15px; border: none; }"
                                "QPushButton:hover { background-color: #3F37C9; }");

    keyLayout->addWidget(new QLabel("Số nguyên tố p:"), 0, 0); keyLayout->addWidget(txtP, 0, 1);
    keyLayout->addWidget(new QLabel("Số nguyên tố q:"), 0, 2); keyLayout->addWidget(txtQ, 0, 3);
    keyLayout->addWidget(new QLabel("Mô-đun số lớn (n):"), 0, 4); keyLayout->addWidget(txtN, 0, 5);

    keyLayout->addWidget(new QLabel("Khóa công khai (e):"), 1, 0); keyLayout->addWidget(txtE, 1, 1);
    keyLayout->addWidget(new QLabel("Khóa bí mật (d):"), 1, 2); keyLayout->addWidget(txtD, 1, 3);

    QHBoxLayout *keyBtnLayout = new QHBoxLayout();
    keyBtnLayout->addWidget(btnGenerate); keyBtnLayout->addWidget(btnCalculate);
    keyLayout->addLayout(keyBtnLayout, 1, 4, 1, 2);

    mainLayout->addWidget(boxKey);

    // ==========================================
    // 2. HỆ THỐNG TAB MÃ HÓA & GIẢI MÃ
    // ==========================================
    QTabWidget *tabWidget = new QTabWidget(this);

    QString btnActionStyle = "QPushButton { background-color: #4CC9F0; color: #2B2D42; font-weight: bold; font-size: 13px; padding: 8px 20px; border-radius: 6px; border: none; }"
                             "QPushButton:hover { background-color: #48CAE4; }";
    QString btnClearStyle = "QPushButton { background-color: #EF233C; color: white; font-weight: bold; padding: 8px 20px; border-radius: 6px; border: none; }"
                            "QPushButton:hover { background-color: #D90429; }";
    QString btnRunStyle = "QPushButton { background-color: #4BB543; color: white; font-weight: bold; font-size: 14px; padding: 12px 30px; border-radius: 6px; border: none; }"
                          "QPushButton:hover { background-color: #3AA133; }";

    // ---- TAB MÃ HÓA ----
    QWidget *encTab = new QWidget();
    QVBoxLayout *encLayout = new QVBoxLayout(encTab);
    txtPlainIn = new QTextEdit(); txtPlainIn->setPlaceholderText("Nhập chuỗi văn bản thường tại đây...");
    txtCipherOut = new QTextEdit(); txtCipherOut->setReadOnly(true);
    btnEncrypt = new QPushButton("🔒 TIẾN HÀNH MÃ HÓA");
    btnEncrypt->setStyleSheet(btnRunStyle);

    btnClearEnc = new QPushButton("Xóa sạch"); btnClearEnc->setStyleSheet(btnClearStyle);
    btnCopyEnc = new QPushButton("📋 Sao chép Hex"); btnCopyEnc->setStyleSheet(btnActionStyle);

    encLayout->addWidget(new QLabel("Văn bản gốc (Plaintext):"));
    encLayout->addWidget(txtPlainIn);
    encLayout->addWidget(btnEncrypt, 0, Qt::AlignCenter);
    encLayout->addWidget(new QLabel("Kết quả mã hóa (Dạng Hex):"));
    encLayout->addWidget(txtCipherOut);

    QHBoxLayout *encBotBtns = new QHBoxLayout();
    encBotBtns->addWidget(btnClearEnc); encBotBtns->addStretch();
    encBotBtns->addWidget(btnCopyEnc);
    encLayout->addLayout(encBotBtns);

    tabWidget->addTab(encTab, "  MÃ HÓA VĂN BẢN  ");

    // ---- TAB GIẢI MÃ ----
    QWidget *decTab = new QWidget();
    QVBoxLayout *decLayout = new QVBoxLayout(decTab);
    txtCipherIn = new QTextEdit(); txtCipherIn->setPlaceholderText("Dán mã Hex vào đây (ví dụ: A3 B2 1F)...");
    txtPlainOut = new QTextEdit(); txtPlainOut->setReadOnly(true);
    btnDecrypt = new QPushButton("🔓 TIẾN HÀNH GIẢI MÃ");
    btnDecrypt->setStyleSheet(btnRunStyle);

    btnClearDec = new QPushButton("Xóa sạch"); btnClearDec->setStyleSheet(btnClearStyle);
    btnCopyDec = new QPushButton("📋 Sao chép văn bản"); btnCopyDec->setStyleSheet(btnActionStyle);

    decLayout->addWidget(new QLabel("Văn bản mã hóa (Ciphertext Hex):"));
    decLayout->addWidget(txtCipherIn);
    decLayout->addWidget(btnDecrypt, 0, Qt::AlignCenter);
    decLayout->addWidget(new QLabel("Văn bản giải mã thành công:"));
    decLayout->addWidget(txtPlainOut);

    QHBoxLayout *decBotBtns = new QHBoxLayout();
    decBotBtns->addWidget(btnClearDec); decBotBtns->addStretch();
    decBotBtns->addWidget(btnCopyDec);
    decLayout->addLayout(decBotBtns);

    tabWidget->addTab(decTab, "  GIẢI MÃ VĂN BẢN  ");

    mainLayout->addWidget(tabWidget);
    setCentralWidget(centralWidget);

    // KẾT NỐI SỰ KIỆN CLICK NÚT BẤM
    connect(btnGenerate, &QPushButton::clicked, this, &MainWindow::on_btnGenerate_clicked);
    connect(btnCalculate, &QPushButton::clicked, this, &MainWindow::on_btnCalculate_clicked);
    connect(btnEncrypt, &QPushButton::clicked, this, &MainWindow::on_btnEncrypt_clicked);
    connect(btnDecrypt, &QPushButton::clicked, this, &MainWindow::on_btnDecrypt_clicked);
    connect(btnClearEnc, &QPushButton::clicked, this, &MainWindow::on_btnClearEncrypt_clicked);
    connect(btnClearDec, &QPushButton::clicked, this, &MainWindow::on_btnClearDecrypt_clicked);
    connect(btnCopyEnc, &QPushButton::clicked, [this](){ QApplication::clipboard()->setText(txtCipherOut->toPlainText()); });
    connect(btnCopyDec, &QPushButton::clicked, [this](){ QApplication::clipboard()->setText(txtPlainOut->toPlainText()); });

    connect(txtP, &QLineEdit::editingFinished, this, &MainWindow::validatePrimeInputs);
    connect(txtQ, &QLineEdit::editingFinished, this, &MainWindow::validatePrimeInputs);
}

MainWindow::~MainWindow() {}

// ==========================================
// THUẬT TOÁN RSA
// ==========================================

long long MainWindow::gcd(long long a, long long b) {
    while (b) { a %= b; std::swap(a, b); }
    return a;
}

long long MainWindow::modPow(long long base, long long exp, long long mod) {
    long long res = 1;
    base %= mod;
    while (exp > 0) {
        if (exp % 2 == 1) res = (__int128)res * base % mod;
        base = (__int128)base * base % mod;
        exp /= 2;
    }
    return res;
}

long long MainWindow::modInverse(long long e, long long phi) {
    long long t = 0, newt = 1;
    long long r = phi, newr = e;
    while (newr != 0) {
        long long quotient = r / newr;
        std::tie(t, newt) = std::make_pair(newt, t - quotient * newt);
        std::tie(r, newr) = std::make_pair(newr, r - quotient * newr);
    }
    if (r > 1) return -1;
    if (t < 0) t += phi;
    return t;
}

void MainWindow::on_btnGenerate_clicked()
{
    long long p = randomPrime(1000, 5000);
    long long q;
    do { q = randomPrime(1000, 5000); } while (p == q);

    txtP->setText(QString::number(p));
    txtQ->setText(QString::number(q));
    on_btnCalculate_clicked();
}

void MainWindow::on_btnCalculate_clicked() {
    long long p = txtP->text().toLongLong();
    long long q = txtQ->text().toLongLong();
    if (p <= 1 || q <= 1) {
        QMessageBox::warning(this, "Lỗi", "Vui lòng nhập số nguyên tố p, q hợp lệ.");
        return;
    }
    long long n = p * q;
    long long phi = (p - 1) * (q - 1);

    long long e = 65537;
    while (gcd(e, phi) != 1 && e < phi) { e += 2; }

    long long d = modInverse(e, phi);

    txtN->setText(QString::number(n));
    txtE->setText(QString::number(e));
    txtD->setText(QString::number(d));
}

void MainWindow::on_btnEncrypt_clicked() {
    long long e = txtE->text().toLongLong();
    long long n = txtN->text().toLongLong();
    QString plainText = txtPlainIn->toPlainText();

    if (e == 0 || n == 0 || plainText.isEmpty()) {
        QMessageBox::information(this, "Thông báo", "Vui lòng tạo khóa và nhập văn bản cần mã hóa.");
        return;
    }

    QString cipherText = "";
    for (int i = 0; i < plainText.length(); ++i) {
        long long m = plainText[i].unicode();
        long long c = modPow(m, e, n);
        cipherText += QString("%1 ").arg(c, 0, 16).toUpper();
    }
    txtCipherOut->setText(cipherText.trimmed());
}

void MainWindow::on_btnDecrypt_clicked() {
    long long d = txtD->text().toLongLong();
    long long n = txtN->text().toLongLong();
    QString cipherText = txtCipherIn->toPlainText();

    if (d == 0 || n == 0 || cipherText.isEmpty()) {
        QMessageBox::information(this, "Thông báo", "Vui lòng cấu hình khóa d, n và nhập mã Hex cần giải mã.");
        return;
    }

    QString plainText = "";
    QStringList tokens = cipherText.split(' ', Qt::SkipEmptyParts);
    for (const QString &token : tokens) {
        bool ok;
        long long c = token.toLongLong(&ok, 16);
        if (ok) {
            long long m = modPow(c, d, n);
            plainText += QChar((int)m);
        }
    }
    txtPlainOut->setText(plainText);
}
S
void MainWindow::on_btnClearEncrypt_clicked() { txtPlainIn->clear(); txtCipherOut->clear(); }
void MainWindow::on_btnClearDecrypt_clicked() { txtCipherIn->clear(); txtPlainOut->clear(); }


bool MainWindow::isPrime(long long n, int k)
{
    if (n < 2) return false;
    if (n == 2 || n == 3) return true;
    if (n % 2 == 0) return false;

    long long d = n - 1;
    int r = 0;

    while ((d & 1) == 0)
    {
        d >>= 1;
        r++;
    }

    std::mt19937_64 rng(
        std::chrono::steady_clock::now().time_since_epoch().count());

    std::uniform_int_distribution<long long> dist(2, n - 2);

    for (int i = 0; i < k; i++)
    {
        long long a = dist(rng);
        long long x = modPow(a, d, n);

        if (x == 1 || x == n - 1)
            continue;

        bool composite = true;

        for (int j = 1; j < r; j++)
        {
            x = modPow(x, 2, n);

            if (x == n - 1)
            {
                composite = false;
                break;
            }
        }

        if (composite)
            return false;
    }

    return true;
}

long long MainWindow::randomPrime(long long min, long long max)
{
    std::mt19937_64 rng(
        std::chrono::steady_clock::now().time_since_epoch().count());

    std::uniform_int_distribution<long long> dist(min, max);

    while (true)
    {
        long long candidate = dist(rng);

        if (candidate % 2 == 0)
            candidate++;

        while (candidate <= max)
        {
            if (isPrime(candidate))
                return candidate;

            candidate += 2;
        }
    }
}

void MainWindow::validatePrimeInputs()
{
    QLineEdit *edit = qobject_cast<QLineEdit*>(sender());

    if (!edit) return;

    bool ok;
    long long value = edit->text().toLongLong(&ok);

    if (!ok)
    {
        QMessageBox::warning(this,"Lỗi","Giá trị phải là số nguyên.");
        edit->clear();
        return;
    }

    if (!isPrime(value))
    {
        QMessageBox::warning(this,"Lỗi",
                             QString("%1 không phải số nguyên tố.").arg(value));
        edit->clear();
    }
}
