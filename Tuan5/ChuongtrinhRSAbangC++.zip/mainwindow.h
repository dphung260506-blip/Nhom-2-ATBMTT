#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>
#include <random>

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_btnGenerate_clicked();
    void on_btnCalculate_clicked();
    void on_btnEncrypt_clicked();
    void on_btnDecrypt_clicked();
    void on_btnClearEncrypt_clicked();
    void on_btnClearDecrypt_clicked();
    void validatePrimeInputs();

private:
    // Khu vực cấu hình khóa
    QLineEdit *txtP, *txtQ, *txtN, *txtE, *txtD;
    QPushButton *btnGenerate, *btnCalculate;

    // Khu vực Mã hóa
    QTextEdit *txtPlainIn, *txtCipherOut;
    QPushButton *btnEncrypt, *btnClearEnc, *btnCopyEnc;

    // Khu vực Giải mã
    QTextEdit *txtCipherIn, *txtPlainOut;
    QPushButton *btnDecrypt, *btnClearDec, *btnCopyDec;

    // Các hàm toán học bổ trợ RSA
    long long gcd(long long a, long long b);
    long long modPow(long long base, long long exp, long long mod);
    long long modInverse(long long e, long long phi);
    bool isPrime(long long n, int k = 5);
    long long randomPrime(long long min, long long max);
};

#endif // MAINWINDOW_H